/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package controle;

import entidades.Pessoa;
import java.util.ArrayList;
import java.util.List;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;

/**
 *
 * @author jaimedias
 */
@ManagedBean
@SessionScoped
public class PessoaControle {

    private Pessoa pessoa = new Pessoa();
    private List<Pessoa> listaPessoas = new ArrayList<>();

    public void salvar() {
        listaPessoas.add(pessoa);
        pessoa = new Pessoa();
    }

    public void remover(Pessoa pes) {
        listaPessoas.remove(pes);
    }

    public Pessoa getPessoa() {
        return pessoa;
    }

    public void setEstado(Pessoa pessoa) {
        this.pessoa = pessoa;
    }

    public List<Pessoa> getListaPessoas() {
        return listaPessoas;
    }

    public void setListaEstados(List<Pessoa> listaPessoas) {
        this.listaPessoas = listaPessoas;
    }

    public String cadastroPessoa() {
        return "CadastroPessoas";
    }

}
